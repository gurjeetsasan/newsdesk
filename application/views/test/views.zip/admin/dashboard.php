<div class="row">	
	<?php echo $this->lang->line('this_is_a_dashboard') ?>
</div><!--/.row-->

