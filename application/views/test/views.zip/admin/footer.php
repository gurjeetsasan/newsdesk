<script src="<?php echo base_url(); ?>template/js/jquery-1.11.1.min.js"></script>
<script src="<?php echo base_url(); ?>template/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>template/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>template/js/custom.js"></script>
