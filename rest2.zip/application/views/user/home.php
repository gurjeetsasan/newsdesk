<h1> Welcome to user Dashboard. </h1>

<h2><a href="http://localhost/rest2/index.php/login/logout">Logout</a></h2>