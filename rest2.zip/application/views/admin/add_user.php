<div class="row">
	<?php echo "This is a Add new user page!"; ?>
</div><!--/.row-->
