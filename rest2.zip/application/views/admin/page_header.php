<div class="row">
	<ol class="breadcrumb">
		<li><a href="<?php echo base_url();?>index.php/admin/"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
		<li class="active"><?php echo $page_title; ?></li>
	</ol>
</div><!--/.row-->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header"> <?php echo $page_title; ?></h1>
	</div>
</div><!--/.row-->
